export default function Advancedata() {
  return (
    <div className="offer">
      <div className="mt-2">
        <label className="text-[#333335] text-sm md:text-base w-[10%] ">
          Purchase note
        </label>
        <input type="text" className="w-[50%] ml-4  rounded-md" />
      </div>
      <div className="mt-2">
        <label className="text-[#333335] text-sm md:text-base w-[10%] ">
          Menu order
        </label>
        <input type="text" className="w-[50%] ml-4  rounded-md" />
      </div>
      <div className="mt-2">
        <label className="text-[#333335] text-sm md:text-base w-[10%] ">
          Menu order
        </label>
        <input type="text" className="w-[50%] ml-4  rounded-md" />
      </div>
    </div>
  );
}
