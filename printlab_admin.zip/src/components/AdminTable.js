const AdminTable = () => {
    return (
        <div>
            
        </div>
    );
};

export default AdminTable;